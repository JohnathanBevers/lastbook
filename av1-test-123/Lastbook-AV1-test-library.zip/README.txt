Lastbook AV1 test library, for PR #123 (issue #49)

What's here: a complete, tiny LastbookData with one video.
- library-data/videos/test/lastbook-av1-test.mp4: 10 seconds of AV1 (1280x720, 30 fps) with AAC sound. It is ffmpeg's own built-in testsrc2 pattern and a 440 Hz tone, so it holds no copyrighted material and can be redistributed freely.
- derived/video-compat/h264-v1/: its H.264 copy and manifest.json, made by mobile/ipad/tools/videocompat from the same repository, exactly as for a real library.

How to try it, from a checkout of PR #123's branch:
1. Unzip this folder.
2. python3 server.py --data /path/to/LastbookData --no-index
   (or LASTBOOK_DATA=/path/to/LastbookData python3 app/main.py for the desktop app)
3. Open http://127.0.0.1:8890/#/watch/video-lastbook-av1-test

What to expect:
- On a Mac without an AV1 decoder (M1, M2): the video plays from the H.264 copy. The player's address ends in ?copy=h264.
- On a Mac with one (M3 and later): the AV1 original plays, as before.
- Without the copy (rename derived/video-compat, then restart): on M1 or M2 the player shows the AV1 message from #56 instead.
- python3 tools/check_video_formats.py --data /path/to/LastbookData reports 1 AV1 video with a usable copy.

How it was made:
- Apple M5 Pro, macOS 26.6.2 (25G83)
- ffmpeg 9.0.2 from Homebrew, with libsvtav1 (SVT-AV1 4.2.0):
  ffmpeg -f lavfi -i "testsrc2=size=1280x720:rate=30:duration=10" -f lavfi -i "sine=frequency=440:duration=10" -c:v libsvtav1 -preset 8 -crf 40 -pix_fmt yuv420p -g 60 -c:a aac -b:a 96k -movflags +faststart -map_metadata -1 lastbook-av1-test.mp4
- The copy: xcrun swiftc -O -o videocompat mobile/ipad/tools/videocompat/main.swift, then ./videocompat LastbookData/library-data LastbookData/derived/video-compat
